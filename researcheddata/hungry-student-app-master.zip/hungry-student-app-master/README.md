# Hungry Student App

<p align="center">
  <img alt="hungry-student-app" src="https://raw.githubusercontent.com/aiy-voice-assistant/hungry-student-app/master/logo.png" height="240" />
</p>

Hungry Student APP has been developed in 24h during the "Like@Home" hackathon in Turin the 30-31th MArch 2019. It's an home assistant that use natural language processor and it is able to connect to the Google Assistant or Cloud Speech-to-Text service. Check out our [presentation](https://prezi.com/gcdsh_eg6-uu/aiy/?utm_campaign=share&utm_medium=copy).

Thanks to this assistant we got the first place.

The used kit for the hackathon has been for [AIY Voice Kit from Google](https://aiyprojects.withgoogle.com/voice/).

# Main aspect

To develop our assistan we cared about four main aspect of the life of students away from home (topic of the hackathon):
  1. Time: students spend a lot of time in the University, then they have very little time to perfrom home activities
  2. Health: a lot of students lead a sedentary life, moreover due to the booredom of cooking thay eat a lot of junk food
  3. Money: not only students but also all people want the best service at the best price
  4. Comodity: all the services just described offered for maximum comfort
  
After this kind of anlisys we start to develop the assistant.

# Features

Thanks to this assistan you will be able to:
  1. **Cook what you have**:
  
      By listing the ingredients left in your fridge the assistant will provide you a list of receipes that you can do only with that ingredients. Then you can choose the receipes you prefer and start to cooking.
      
      The assistant will report you the preparation time, calories and of course the steps needed to prepare the choosen receipe.
      
  2. **Order what you want**:
  
      If you are too tired uot or you do not want to cook you can order what you want: just say to the assistant what you would like to eat and it will search in the major delivery food (deliveroo, glovo, just eat) and it will say to you which the service with the best price.
      
  3. **Let it take care of you**:
  
      Every time you will use the assistan to cook or to order food, it will keep trace of what you eat with the related calories. In this way it is able to advise you when you should eat something healthy.
      
